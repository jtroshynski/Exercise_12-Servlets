package mvc;

public class Question {
	public String question;
	public int id;
	public Question(int id, String question) {
		this.question = question;
		this.id = id;
	}
}

