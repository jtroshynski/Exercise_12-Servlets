package mvc.models;

import java.util.List;

import mvc.Answer;

public class AnswerViewModel {
	public List<Answer> answers;
}
