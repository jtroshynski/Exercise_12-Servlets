package mvc.models;

import java.util.List;

import mvc.Question;

public class QuestionViewModel {
	public List<Question> questions;
}
